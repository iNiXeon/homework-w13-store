const initialState = {
  token: '',
  user: {
    name: ''
  }
}
/* eslint-disable default-param-last */
export default (state = initialState, action) => {
  switch (action.type) {
    default:
      return state
  }
}
